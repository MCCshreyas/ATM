﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATM.Model
{
    public static class InitializeData
    {
        public static List<User> users = new List<User>();

        public static void SetupSampleData()
        {
            User first = new User()
            {
                Name = "Shreyas Jejurkar",
                AccountNumber = "99999999",
                Amount = 300,
                PIN = 1234
            };

            users.Add(first);

            users.Add(new User()
            {
                Name = "Narayan Shinde",
                AccountNumber = "4444444",
                Amount = 500,
                PIN = 1212
            });

            users.Add(new User()
            {
                Name = "Praveen Kadhbhane",
                AccountNumber = "555555",
                Amount = 1000,
                PIN = 9090
            });
        }
    }
}
