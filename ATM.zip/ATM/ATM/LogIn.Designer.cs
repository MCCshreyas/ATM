﻿namespace ATM
{
    partial class LogIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Panel_LogIn = new System.Windows.Forms.Panel();
            this.Panel_Dashboard = new System.Windows.Forms.Panel();
            this.panel_withdraw = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button_cancel = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.button_withdrawMoney = new System.Windows.Forms.Button();
            this.button_depositeMoney = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label_amount = new System.Windows.Forms.Label();
            this.label_accountNumber = new System.Windows.Forms.Label();
            this.button_logout = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label_welcome = new System.Windows.Forms.Label();
            this.Button_LogIn = new System.Windows.Forms.Button();
            this.TextBox_PIN = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TextBox_AccountNumber = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_deposite = new System.Windows.Forms.Panel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.Panel_LogIn.SuspendLayout();
            this.Panel_Dashboard.SuspendLayout();
            this.panel_withdraw.SuspendLayout();
            this.panel_deposite.SuspendLayout();
            this.SuspendLayout();
            // 
            // Panel_LogIn
            // 
            this.Panel_LogIn.Controls.Add(this.Panel_Dashboard);
            this.Panel_LogIn.Controls.Add(this.Button_LogIn);
            this.Panel_LogIn.Controls.Add(this.TextBox_PIN);
            this.Panel_LogIn.Controls.Add(this.label3);
            this.Panel_LogIn.Controls.Add(this.TextBox_AccountNumber);
            this.Panel_LogIn.Controls.Add(this.label2);
            this.Panel_LogIn.Controls.Add(this.label1);
            this.Panel_LogIn.Location = new System.Drawing.Point(12, 12);
            this.Panel_LogIn.Name = "Panel_LogIn";
            this.Panel_LogIn.Size = new System.Drawing.Size(681, 384);
            this.Panel_LogIn.TabIndex = 0;
            // 
            // Panel_Dashboard
            // 
            this.Panel_Dashboard.Controls.Add(this.panel_withdraw);
            this.Panel_Dashboard.Controls.Add(this.button_withdrawMoney);
            this.Panel_Dashboard.Controls.Add(this.button_depositeMoney);
            this.Panel_Dashboard.Controls.Add(this.label9);
            this.Panel_Dashboard.Controls.Add(this.label8);
            this.Panel_Dashboard.Controls.Add(this.label_amount);
            this.Panel_Dashboard.Controls.Add(this.label_accountNumber);
            this.Panel_Dashboard.Controls.Add(this.button_logout);
            this.Panel_Dashboard.Controls.Add(this.label4);
            this.Panel_Dashboard.Controls.Add(this.label5);
            this.Panel_Dashboard.Controls.Add(this.label_welcome);
            this.Panel_Dashboard.Location = new System.Drawing.Point(0, 0);
            this.Panel_Dashboard.Name = "Panel_Dashboard";
            this.Panel_Dashboard.Size = new System.Drawing.Size(681, 384);
            this.Panel_Dashboard.TabIndex = 6;
            // 
            // panel_withdraw
            // 
            this.panel_withdraw.Controls.Add(this.panel_deposite);
            this.panel_withdraw.Controls.Add(this.textBox1);
            this.panel_withdraw.Controls.Add(this.button_cancel);
            this.panel_withdraw.Controls.Add(this.label7);
            this.panel_withdraw.Controls.Add(this.label11);
            this.panel_withdraw.Controls.Add(this.button3);
            this.panel_withdraw.Controls.Add(this.label12);
            this.panel_withdraw.Controls.Add(this.label13);
            this.panel_withdraw.Controls.Add(this.label14);
            this.panel_withdraw.Location = new System.Drawing.Point(0, 0);
            this.panel_withdraw.Name = "panel_withdraw";
            this.panel_withdraw.Size = new System.Drawing.Size(681, 384);
            this.panel_withdraw.TabIndex = 12;
            this.panel_withdraw.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel1_Paint);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(359, 122);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(142, 20);
            this.textBox1.TabIndex = 11;
            // 
            // button_cancel
            // 
            this.button_cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_cancel.Location = new System.Drawing.Point(174, 255);
            this.button_cancel.Name = "button_cancel";
            this.button_cancel.Size = new System.Drawing.Size(155, 31);
            this.button_cancel.TabIndex = 10;
            this.button_cancel.Text = "Cancel";
            this.button_cancel.UseVisualStyleBackColor = true;
            this.button_cancel.Click += new System.EventHandler(this.Button_cancel_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(324, 119);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 19);
            this.label7.TabIndex = 8;
            this.label7.Text = "-";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(192, 141);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 19);
            this.label11.TabIndex = 6;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(346, 255);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(155, 31);
            this.button3.TabIndex = 5;
            this.button3.Text = "Withdraw";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(192, 122);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(111, 19);
            this.label12.TabIndex = 3;
            this.label12.Text = "Enter amount";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(275, 47);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(134, 19);
            this.label13.TabIndex = 1;
            this.label13.Text = "Withdraw Money";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(40, 64);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(0, 24);
            this.label14.TabIndex = 0;
            // 
            // button_withdrawMoney
            // 
            this.button_withdrawMoney.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_withdrawMoney.Location = new System.Drawing.Point(457, 69);
            this.button_withdrawMoney.Name = "button_withdrawMoney";
            this.button_withdrawMoney.Size = new System.Drawing.Size(155, 31);
            this.button_withdrawMoney.TabIndex = 11;
            this.button_withdrawMoney.Text = "Withdraw money";
            this.button_withdrawMoney.UseVisualStyleBackColor = true;
            this.button_withdrawMoney.Click += new System.EventHandler(this.Button_withdrawMoney_Click);
            // 
            // button_depositeMoney
            // 
            this.button_depositeMoney.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_depositeMoney.Location = new System.Drawing.Point(457, 178);
            this.button_depositeMoney.Name = "button_depositeMoney";
            this.button_depositeMoney.Size = new System.Drawing.Size(155, 31);
            this.button_depositeMoney.TabIndex = 10;
            this.button_depositeMoney.Text = "Deposit money";
            this.button_depositeMoney.UseVisualStyleBackColor = true;
            this.button_depositeMoney.Click += new System.EventHandler(this.Button_depositeMoney_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(110, 190);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(16, 19);
            this.label9.TabIndex = 9;
            this.label9.Text = "-";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(170, 146);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(16, 19);
            this.label8.TabIndex = 8;
            this.label8.Text = "-";
            // 
            // label_amount
            // 
            this.label_amount.AutoSize = true;
            this.label_amount.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_amount.Location = new System.Drawing.Point(192, 190);
            this.label_amount.Name = "label_amount";
            this.label_amount.Size = new System.Drawing.Size(0, 19);
            this.label_amount.TabIndex = 7;
            // 
            // label_accountNumber
            // 
            this.label_accountNumber.AutoSize = true;
            this.label_accountNumber.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_accountNumber.Location = new System.Drawing.Point(192, 141);
            this.label_accountNumber.Name = "label_accountNumber";
            this.label_accountNumber.Size = new System.Drawing.Size(0, 19);
            this.label_accountNumber.TabIndex = 6;
            // 
            // button_logout
            // 
            this.button_logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_logout.Location = new System.Drawing.Point(457, 292);
            this.button_logout.Name = "button_logout";
            this.button_logout.Size = new System.Drawing.Size(155, 31);
            this.button_logout.TabIndex = 5;
            this.button_logout.Text = "Log out";
            this.button_logout.UseVisualStyleBackColor = true;
            this.button_logout.Click += new System.EventHandler(this.Button_logout_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(31, 190);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "Amount";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(31, 146);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 19);
            this.label5.TabIndex = 1;
            this.label5.Text = "Account Number";
            // 
            // label_welcome
            // 
            this.label_welcome.AutoSize = true;
            this.label_welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_welcome.Location = new System.Drawing.Point(40, 64);
            this.label_welcome.Name = "label_welcome";
            this.label_welcome.Size = new System.Drawing.Size(0, 24);
            this.label_welcome.TabIndex = 0;
            // 
            // Button_LogIn
            // 
            this.Button_LogIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_LogIn.Location = new System.Drawing.Point(238, 141);
            this.Button_LogIn.Name = "Button_LogIn";
            this.Button_LogIn.Size = new System.Drawing.Size(243, 31);
            this.Button_LogIn.TabIndex = 5;
            this.Button_LogIn.Text = "Log in";
            this.Button_LogIn.UseVisualStyleBackColor = true;
            this.Button_LogIn.Click += new System.EventHandler(this.Button_LogIn_Click);
            // 
            // TextBox_PIN
            // 
            this.TextBox_PIN.Location = new System.Drawing.Point(328, 99);
            this.TextBox_PIN.Name = "TextBox_PIN";
            this.TextBox_PIN.Size = new System.Drawing.Size(153, 20);
            this.TextBox_PIN.TabIndex = 4;
            this.TextBox_PIN.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_PIN_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(235, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "PIN";
            // 
            // TextBox_AccountNumber
            // 
            this.TextBox_AccountNumber.Location = new System.Drawing.Point(328, 69);
            this.TextBox_AccountNumber.Name = "TextBox_AccountNumber";
            this.TextBox_AccountNumber.Size = new System.Drawing.Size(153, 20);
            this.TextBox_AccountNumber.TabIndex = 2;
            this.TextBox_AccountNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_AccountNumber_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(235, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Account Number";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(301, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Log in";
            // 
            // panel_deposite
            // 
            this.panel_deposite.Controls.Add(this.textBox2);
            this.panel_deposite.Controls.Add(this.button1);
            this.panel_deposite.Controls.Add(this.label6);
            this.panel_deposite.Controls.Add(this.label10);
            this.panel_deposite.Controls.Add(this.button2);
            this.panel_deposite.Controls.Add(this.label15);
            this.panel_deposite.Controls.Add(this.label16);
            this.panel_deposite.Controls.Add(this.label17);
            this.panel_deposite.Location = new System.Drawing.Point(0, 0);
            this.panel_deposite.Name = "panel_deposite";
            this.panel_deposite.Size = new System.Drawing.Size(681, 384);
            this.panel_deposite.TabIndex = 13;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(359, 122);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(142, 20);
            this.textBox2.TabIndex = 11;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(174, 255);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(155, 31);
            this.button1.TabIndex = 10;
            this.button1.Text = "Cancel";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(324, 119);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(16, 19);
            this.label6.TabIndex = 8;
            this.label6.Text = "-";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(192, 141);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 19);
            this.label10.TabIndex = 6;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(346, 255);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(155, 31);
            this.button2.TabIndex = 5;
            this.button2.Text = "Withdraw";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(192, 122);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(111, 19);
            this.label15.TabIndex = 3;
            this.label15.Text = "Enter amount";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(275, 47);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(129, 19);
            this.label16.TabIndex = 1;
            this.label16.Text = "Deposite Money";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(40, 64);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(0, 24);
            this.label17.TabIndex = 0;
            // 
            // LogIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(703, 406);
            this.Controls.Add(this.Panel_LogIn);
            this.Name = "LogIn";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Panel_LogIn.ResumeLayout(false);
            this.Panel_LogIn.PerformLayout();
            this.Panel_Dashboard.ResumeLayout(false);
            this.Panel_Dashboard.PerformLayout();
            this.panel_withdraw.ResumeLayout(false);
            this.panel_withdraw.PerformLayout();
            this.panel_deposite.ResumeLayout(false);
            this.panel_deposite.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Panel_LogIn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TextBox_PIN;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TextBox_AccountNumber;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Button_LogIn;
        private System.Windows.Forms.Panel Panel_Dashboard;
        private System.Windows.Forms.Button button_logout;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label_welcome;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button_withdrawMoney;
        private System.Windows.Forms.Button button_depositeMoney;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label_amount;
        private System.Windows.Forms.Label label_accountNumber;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel_withdraw;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button_cancel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel_deposite;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
    }
}

