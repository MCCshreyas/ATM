﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using ATM.Model;

namespace ATM
{   
    public partial class LogIn : Form
    {
        User logInUser = new User();
        List<Panel> allpanels = new List<Panel>();
        public LogIn()
        {
            InitializeComponent();
            Panel_LogIn.Visible = true;
            panel_withdraw.Visible = false;
            Panel_Dashboard.Visible = false;
            panel_deposite.Hide();
             StartPosition = FormStartPosition.CenterScreen;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitializeData.SetupSampleData();
        }

        private bool DoValidation()
        {
            if(TextBox_AccountNumber.Text == string.Empty || TextBox_PIN.Text == string.Empty)
            {
                MessageBox.Show("Please fill all the fields", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        private User CheckCredentials(string acc, int PIN)
        {
            var user = InitializeData.users.FirstOrDefault(u => u.AccountNumber == acc && u.PIN == PIN);

            if(user != null)
            {
                return user;
            }
            else
            {
                return null;
            }
        }

        private void Button_LogIn_Click(object sender, EventArgs e)
        {
            if(DoValidation())
            {
                var loggedInUser = CheckCredentials(TextBox_AccountNumber.Text, Convert.ToInt32(TextBox_PIN.Text));
                
                if(loggedInUser == null)
                {
                    MessageBox.Show("Incorrect credentials", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show($"Welcome {loggedInUser.Name} ", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Panel2Controls(loggedInUser);
                    logInUser = loggedInUser;
                }
            }
        }

        private void Panel2Controls(User user)
        {
            Panel_Dashboard.Visible = true;
            Panel_Dashboard.BringToFront();
            

            label_welcome.Text = $"Welcome {user.Name}";
            label_accountNumber.Text = user.AccountNumber;
            label_amount.Text = user.Amount.ToString();
        
        }


        private void TextBox_AccountNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void TextBox_PIN_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void Button_logout_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure to logout?","Warning",MessageBoxButtons.YesNo,MessageBoxIcon.Question);

            if(dr == DialogResult.Yes)
            {
               
                Panel_LogIn.Show();
            }
            else if(dr == DialogResult.No)
            {

            }

        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Button_withdrawMoney_Click(object sender, EventArgs e)
        {
            panel_withdraw.Show();
        }

        private void Button_depositeMoney_Click(object sender, EventArgs e)
        {
            panel_deposite.Show();
        }

        private void Button_cancel_Click(object sender, EventArgs e)
        {
            panel_withdraw.Hide();
        }

        //private void Button_deposite_Click(object sender, EventArgs e)
        //{
        //    var depositeAmount = Convert.ToInt32(textBox_amount_deposite.Text);

        //    logInUser.Amount = depositeAmount;
        //    MessageBox.Show("Amount deposited", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //    panel_deposite.Hide();
        //}

        private void Button_cancel2_Click(object sender, EventArgs e)
        {
           
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            panel_deposite.Hide();
            Panel_Dashboard.Show();
        }
    }
}
