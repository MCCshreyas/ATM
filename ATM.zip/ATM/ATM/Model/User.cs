﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATM.Model
{
    public class User
    {
        public string AccountNumber { get; set; }
        public string Name { get; set; }
        public int Amount { get; set; }
        public int PIN { get; set; }
    }
}
